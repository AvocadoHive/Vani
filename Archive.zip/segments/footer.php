<!-- services -->
<section class="u-clearfix u-container-align-center u-palette-4-base u-section-6" id="carousel_35e5">
    <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
    <!-- <h5 class="u-align-center u-text u-text-default u-text-1"> Add more speed to your website</h5> -->
    <h2 class="services-info u-align-center u-custom-font u-font-raleway u-text u-text-2"> Selectium Law Group:<br />Protecting Your Venture. Guarding Your Innovation. Preserving Your Legacy. </h2>
    <!-- <p class="u-align-center u-text u-text-default u-text-3">Sample text. Click to select the Text Element.</p> -->
    <div class="d-down-notes">Experience the <i>Selectium</i> Difference</div>
    <a href="https://nicepage.com/website-builder" class="d-footer-banner-link u-align-center u-border-4 u-border-white u-btn u-btn-round u-button-style u-custom-font u-font-montserrat u-none u-radius-40 u-btn-1" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">Contact us today</a>
    </div>
</section>